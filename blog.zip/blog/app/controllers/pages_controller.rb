class PagesController < ApplicationController
    def index
        @page = Page.all
    end

    def show
        @page = Page.find(params[:id])
    
    end

    def new
        @page = Page.new
        # render plain: params.to_json
    end

    def create
        # render plain: params.to_json
        page_param = params.require(:page).permit(:title, :body, :slug)
        @page = Page.new(page_param)
        @page.save
        redirect_to @page
    end

    def edit
        @page = Page.find(params[:id])
    end
end
